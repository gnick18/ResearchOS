ResearchOS — Demo Lab
=====================

This is a fake research lab dataset shipped with ResearchOS for tutorial purposes.

Lab: Demo Synthetic Biology Lab
Users: alex (PI), morgan (grad student)

How to use
----------
1. Unzip this archive somewhere on your computer (the folder will be named `DemoLab`).
2. Open ResearchOS and choose 'Link Folder'.
3. Pick the `DemoLab` folder.
4. The app will show a yellow banner reminding you that all data is fake.

Everything in this folder is fabricated. Projects are prefixed `DEMO:`, methods are prefixed `[Demo protocol]`, and every image carries a visible `FAKE DEMO` watermark.
